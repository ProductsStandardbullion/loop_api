<?php if($errors->any()): ?>
<div class="alert alert-danger p-3">
    <p><strong>Opps Something went wrong. Alaye, you don do spoil.</strong></p>
    <ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>


<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible text-center p-2" role="alert">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <?php echo e(session('success')); ?>

    </div>
    
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible text-center p-2" role="alert">
        <?php echo e(session('error')); ?>

    </div>
    
<?php endif; ?><?php /**PATH /home/discretematt/dev/web/freelance/loop/loop_webapp_v1.0/resources/views/layouts/feedback.blade.php ENDPATH**/ ?>