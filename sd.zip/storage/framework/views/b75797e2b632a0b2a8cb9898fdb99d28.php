<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8" />
    <title><?php echo e($data['title']); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="<?php echo e($data['description']); ?>" name="description" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('publicLogo.png')); ?>">

    <!-- owl.carousel css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/owl.carousel/assets/owl.carousel.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/owl.carousel/assets/owl.theme.default.min.css')); ?>">

    <!-- Bootstrap Css -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css" />

</head>

<body class="auth-body-bg" style="background: #f8fff7">
    <?php echo $__env->yieldContent('content'); ?>
    <script src="<?php echo e(asset('assets/libs/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/metismenu/metisMenu.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/simplebar/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/node-waves/waves.min.js')); ?>"></script>

    <!-- owl.carousel js -->
    <script src="<?php echo e(asset('assets/libs/owl.carousel/owl.carousel.min.js')); ?>"></script>

    <!-- auth-2-carousel init -->
    <script src="<?php echo e(asset('assets/js/pages/auth-2-carousel.init.js')); ?>"></script>

    <!-- App js -->
    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>

</body>

</html><?php /**PATH /home/discretematt/dev/web/freelance/loop/loop_webapp_v1.0/resources/views/layouts/auth.blade.php ENDPATH**/ ?>