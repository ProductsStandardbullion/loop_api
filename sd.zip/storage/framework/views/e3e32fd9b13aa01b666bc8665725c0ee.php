<?php $__env->startSection('content'); ?>
<div>
    <div class="container-fluid p-0">
        <div class="row g-0">

          
            <!-- end col -->

            <div class="col-xl-3 mx-auto bg-white">
                <div class="auth-full-page-content p-md-5 p-4">
                    <div class="w-100">

                        <div class="d-flex flex-column h-100">
                            <div class="mb-4 mb-md-5">
                                <a href="/" class="d-block auth-logo">
                                    <img src="<?php echo e(asset('logo.png')); ?>" alt="<?php echo e(config('app.name')); ?>" class="auth-logo-dark">
                                </a>
                            </div>
                            <div class="my-auto">

                                <div>
                                    <h5 class="text-primary">Welcome Back !</h5>
                                    <p class="text-muted">Sign in to continue to <?php echo e(config('app.name')); ?>.</p>
                                </div>

                                <div class="mt-4">
                                    <form action="" method="POST">
                                        <?php echo csrf_field(); ?>

                                        <div class="mb-3">
                                            <label for="username" class="form-label mb-0">Email address</label>
                                            <input type="text" class="form-control" id="username"
                                                placeholder="arya.stark@winterfell.com">
                                        </div>

                                        <div class="mb-3">
                                            <div class="float-end">
                                                <a href="#" class="text-muted">Forgot password?</a>
                                            </div>
                                            <label class="form-label mb-0">Password</label>
                                            <div class="input-group auth-pass-inputgroup">
                                                <input type="password" class="form-control" placeholder="Enter password"
                                                    aria-label="Password" aria-describedby="password-addon">
                                                <button class="btn btn-light " type="button" id="password-addon"><i
                                                        class="mdi mdi-eye-outline"></i></button>
                                            </div>
                                        </div>

                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="remember-check">
                                            <label class="form-check-label" for="remember-check">
                                                Remember me
                                            </label>
                                        </div>

                                        <div class="mt-3 d-grid">
                                            <button class="btn btn-primary waves-effect waves-light" type="submit">Log
                                                In</button>
                                        </div>


                                        <div class="mt-4 text-center d-none">
                                            <h5 class="font-size-14 mb-3">Sign in with</h5>

                                            <ul class="list-inline">
                                                <li class="list-inline-item">
                                                    <a href="javascript::void()"
                                                        class="social-list-item bg-primary text-white border-primary">
                                                        <i class="mdi mdi-facebook"></i>
                                                    </a>
                                                </li>
                                                <li class="list-inline-item">
                                                    <a href="javascript::void()"
                                                        class="social-list-item bg-info text-white border-info">
                                                        <i class="mdi mdi-twitter"></i>
                                                    </a>
                                                </li>
                                                <li class="list-inline-item">
                                                    <a href="javascript::void()"
                                                        class="social-list-item bg-danger text-white border-danger">
                                                        <i class="mdi mdi-google"></i>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>

                                    </form>
                                    <div class="mt-5 text-center">
                                        <p>Don't have an account ? <a href="<?php echo e(route('index.register')); ?>"
                                                class="fw-medium text-primary"> Signup now </a> </p>
                                    </div>
                                </div>
                            </div>

                            <div class="mt-4 mt-md-5 text-center">
                                <p class="mb-0">© <script>
                                        document.write(new Date().getFullYear())
                                    </script> Crafted with <i class="mdi mdi-heart text-danger"></i> by
                                    <?php echo e(config('app.name')); ?></p>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
            <!-- end col -->
        </div>
        <!-- end row -->
    </div>
    <!-- end container-fluid -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/discretematt/dev/web/freelance/loop/loop_webapp_v1.0/resources/views/user/auth/login.blade.php ENDPATH**/ ?>