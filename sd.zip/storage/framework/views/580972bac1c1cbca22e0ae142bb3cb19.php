<?php $__env->startSection('content'); ?>
    





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.hq', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/discretematt/dev/web/freelance/loop/loop_webapp_v1.0/resources/views/admin/hq/dashboard/index.blade.php ENDPATH**/ ?>