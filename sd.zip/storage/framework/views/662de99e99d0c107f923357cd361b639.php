<?php $__env->startSection('content'); ?>
<div>
    <div class="container-fluid p-0">
        <div class="row g-0">

            <div class="col-xl-3 mx-auto bg-white">
                <div class="auth-full-page-content p-md-5 p-4">
                    <div class="w-100">

                        <div class="d-flex flex-column h-100">
                            <div class="mb-4 mb-md-5">
                                <a href="index.html" class="d-block auth-logo">
                                    <img src="<?php echo e(asset('logo.png')); ?>" alt="<?php echo e(config('app.name')); ?>"
                                        class="auth-logo-dark">
                                </a>
                            </div>
                            <div class="my-auto">

                                <div>
                                    <h5 class="text-primary">Register account</h5>
                                    <p class="text-muted">Get your free <?php echo e(config('app.name')); ?> account now.</p>
                                </div>

                                <div class="mt-4">
                                    <form method="POST" class="needs-validation" novalidate action="<?php echo e(route('index.register.post')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo $__env->make('layouts.feedback', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                        <div class="mb-3">
                                            <label for="useremail" class="form-label mb-0">First name</label>
                                            <input type="text" name="first_name" value="<?php echo e(old('first_name')); ?>" class="form-control" id="first_name"
                                                placeholder="Arya" required>
                                         
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label mb-0">Last name</label>
                                            <input name="last_name" value="<?php echo e(old('last_name')); ?>" type="text" class="form-control" id="last_name"
                                                placeholder="Stark" required>
                                         
                                        </div>


                                        <div class="mb-3">
                                            <label class="form-label mb-0">Email</label>
                                            <input name="email" value="<?php echo e(old('email')); ?>" type="email" class="form-control" id="useremail"
                                                placeholder="Enter email" required>
                                          
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label mb-0">Phone number</label>
                                            <input name="phone" value="<?php echo e(old('phone')); ?>" type="text" minlength="11" maxlength="11" class="form-control" id="username"
                                                placeholder="080XXXXXXXX" required>
                                     
                                        </div>

                                        <div class="mb-3">
                                            <label for="userpassword" class="form-label mb-0">Password</label>
                                            <input name="password" type="password" class="form-control" id="userpassword"
                                                placeholder="Enter password" required>
                                         
                                        </div>

                                        <div>
                                            <p class="mb-0">By registering you agree to the <?php echo e(config('app.name')); ?> <a
                                                    href="#" class="text-primary">Terms of Use</a></p>
                                        </div>

                                        <div class="mt-4 d-grid">
                                            <button class="btn btn-success waves-effect waves-light"
                                                type="submit">Register</button>
                                        </div>

                                        <div class="mt-4 text-center d-none">
                                            <h5 class="font-size-14 mb-3">Sign up using</h5>

                                            <ul class="list-inline">
                                                <li class="list-inline-item">
                                                    <a href="javascript::void()"
                                                        class="social-list-item bg-primary text-white border-primary">
                                                        <i class="mdi mdi-facebook"></i>
                                                    </a>
                                                </li>
                                                <li class="list-inline-item">
                                                    <a href="javascript::void()"
                                                        class="social-list-item bg-info text-white border-info">
                                                        <i class="mdi mdi-twitter"></i>
                                                    </a>
                                                </li>
                                                <li class="list-inline-item">
                                                    <a href="javascript::void()"
                                                        class="social-list-item bg-danger text-white border-danger">
                                                        <i class="mdi mdi-google"></i>
                                                    </a>
                                                </li>
                                            </ul>

                                        </div>

                                    </form>

                                    <div class="mt-5 text-center">
                                        <p>Already have an account ? <a href="<?php echo e(route('index')); ?>"
                                                class="fw-medium text-primary"> Login</a> </p>
                                    </div>

                                </div>
                            </div>

                            <div class="mt-4 mt-md-5 text-center">
                                <p class="mb-0">© <script>
                                        document.write(new Date().getFullYear())
                                    </script> <?php echo e(config('app.name')); ?>. Crafted with <i
                                        class="mdi mdi-heart text-danger"></i> and coffe </p>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
            <!-- end col -->
        </div>
        <!-- end row -->
    </div>
    <!-- end container-fluid -->
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/discretematt/dev/web/freelance/loop/loop_webapp_v1.0/resources/views/user/auth/register.blade.php ENDPATH**/ ?>