<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card">
        <div class="card-header">
            <h3>Add real estate investment</h3>
        </div>
        <div class="card-body p-4">
            <?php echo $__env->make('layouts.feedback', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <table class="table table-bordered">
                <?php $__currentLoopData = $investment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($key == 'gallery'): ?>
                <div class="row">
                    <?php 
$data = json_decode($value, true);
foreach ($data as $k => $val) {?>
                    <div class="col-md-4">
                        <img class="img-fluid" style="width: 200px" src="<?php echo e($val); ?>" alt="<?php echo e($k); ?>">
                    </div>
                    <?php }

?>
                </div>
                <?php else: ?>
                <tr>
                    <td><?php echo e(str_replace('_',' ', $key)); ?></td>
                    <td><?php echo e($value); ?></td>
                </tr>

                <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
     
    </div>
  <div class="text-center">
    <a href="<?php echo e(route('hq.investment.realestate')); ?>" class="btn btn-dark">Go back</a>
    <a href="<?php echo e(route('hq.investment.realestate.destroy',['id' => $investment->get('id')])); ?>" class="btn btn-danger px-3">Delete</a>
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.hq', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/discretematt/dev/web/freelance/loop/loop_webapp_v1.0/resources/views/admin/hq/investments/realestate/show.blade.php ENDPATH**/ ?>