<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card">
        <div class="card-header">
            <h3>Real estate investments</h3>
        </div>
        <div class="card-body">
            <?php echo $__env->make('layouts.feedback', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <table class="table table-bordered rounded">
<thead>
    <th>Titile</th>
    <th></th>
    <th></th>
</thead>
<tbody>
  <?php $__currentLoopData = $investments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e($item->title); ?></td>
    <td><a href="<?php echo e(route('hq.investment.realestate.show',['investment_id' => $item->investment_id])); ?>" class="btn btn-primary btn-sm px-5">details</a></td>
    <td><a href="<?php echo e(route('hq.investment.realestate.destroy',['id' => $item->id])); ?>" class="btn btn-danger btn-sm px-5">Delete</a></td>
</tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
            </table>
          
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.hq', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/discretematt/dev/web/freelance/loop/loop_webapp_v1.0/resources/views/admin/hq/investments/realestate/index.blade.php ENDPATH**/ ?>